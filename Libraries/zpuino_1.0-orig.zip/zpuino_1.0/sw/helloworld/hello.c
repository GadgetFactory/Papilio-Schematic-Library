// To compile: zpu-elf-gcc test.c -o test.elf -phi
// To run:  
int main(int argc, char **argv)
{
	printf("Hello world!\n");
}
