package com.zylin.zpu.simulator.exceptions;

public class UnknownPacketException extends GDBServerException
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
