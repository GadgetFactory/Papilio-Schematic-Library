/*
 * Created on Nov 16, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package com.zylin.zpu.simulator.exceptions;

/**
 * @author oyvind
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class EndSessionException extends Exception
{

	public EndSessionException()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public EndSessionException(String arg0, Throwable arg1)
	{
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public EndSessionException(String arg0)
	{
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public EndSessionException(Throwable arg0)
	{
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
