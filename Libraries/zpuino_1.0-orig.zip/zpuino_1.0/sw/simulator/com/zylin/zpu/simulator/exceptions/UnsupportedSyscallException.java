
package com.zylin.zpu.simulator.exceptions;

public class UnsupportedSyscallException extends CPUException
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
