package com.zylin.zpu.simulator.exceptions;

public class DebuggerBreakpointException extends CPUException
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
