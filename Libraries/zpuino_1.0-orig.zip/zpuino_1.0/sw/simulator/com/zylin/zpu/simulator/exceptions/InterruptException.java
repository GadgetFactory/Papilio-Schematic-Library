/*
 * Created on 02.jan.2005
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package com.zylin.zpu.simulator.exceptions;


/**
 * @author oyvind
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class InterruptException extends CPUException
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
