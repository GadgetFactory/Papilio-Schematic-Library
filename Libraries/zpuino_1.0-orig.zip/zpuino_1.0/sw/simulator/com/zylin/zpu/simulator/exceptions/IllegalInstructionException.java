/*
 * Created on Oct 23, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package com.zylin.zpu.simulator.exceptions;


/**
 * @author oyvind
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class IllegalInstructionException extends CPUException
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
