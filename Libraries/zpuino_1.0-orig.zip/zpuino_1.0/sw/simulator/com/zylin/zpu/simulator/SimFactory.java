package com.zylin.zpu.simulator;

public interface SimFactory
{

	Simulator create();

}
