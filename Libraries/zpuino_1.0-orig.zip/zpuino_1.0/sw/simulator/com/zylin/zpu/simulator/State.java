package com.zylin.zpu.simulator;


public class State
{

	public long cycle;
	public int insn;
}
