
package com.zylin.zpu.simulator;

/**
 * @author oyvind
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface Machine
{

    long getPrevCycles();

    long getCycles();

}
