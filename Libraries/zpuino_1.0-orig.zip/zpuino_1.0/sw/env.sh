export ZPUSW=`pwd`
export PATH=$PATH:/tmp/zpu/install/bin
