. env.sh
rm -rf /tmp/zpu
mkdir -p /tmp/zpu/install/bin
cd /tmp/zpu
unzip $ZPUSW/tools/zputoolchain.zip

