IMPORT_OPTIONS="--std=93 --ieee=synopsys --workdir=work"
MAKE_OPTIONS="${IMPORT_OPTIONS} -Wl,-s -fexplicit --syn-binding"
