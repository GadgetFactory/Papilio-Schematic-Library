#ifndef __BOARDS_H__
#define __BOARDS_H__

#include <inttypes.h>

const char* getBoardById(uint32_t id);

#endif
