/* Simple hello world */
#include <stdio.h>


int main(int argc, char **argv)
{
	puts("Hello world\n");
}

