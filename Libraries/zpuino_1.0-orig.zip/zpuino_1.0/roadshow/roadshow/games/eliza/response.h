/*
Copyright (C) 1988-2003 by Mohan Embar

http://www.thisiscool.com/
DISCLAIMER: This was written in 1988. I don't code like this anymore!

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version. 

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details. 

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 675 Mass Ave,
Cambridge, MA 02139, USA. 
*/

/* Functions which return responses */

/* Generic question */
char *question();
char *b_word_resp();
char *n_word_resp();
char *because_resp();
char *yes_resp();
char *neg_resp();
char *go_on();
char *always_resp();
char *alike_resp();
char *fam_resp();
char *family_resp();
char *i_am_resp();
char *sad1_word_resp();
char *sad2_word_resp();
char *command_resp();
int randnum();
char *you_resp();
char *you_know();
char *old_fact();
