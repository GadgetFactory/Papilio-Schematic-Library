/*
Copyright (C) 1988-2003 by Mohan Embar

http://www.thisiscool.com/
DISCLAIMER: This was written in 1988. I don't code like this anymore!

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version. 

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details. 

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 675 Mass Ave,
Cambridge, MA 02139, USA. 
*/

extern void parse();
extern void agree();
extern int matches();
extern int sword();
extern void make_lower();
extern int i_am();
extern void get_til_stop();
extern int sad_word();
extern int search_back_sub();
extern int is_helper();
extern char *cnnv();
extern int is_be();
extern int can_spit_out();
extern char *cnnv2();
